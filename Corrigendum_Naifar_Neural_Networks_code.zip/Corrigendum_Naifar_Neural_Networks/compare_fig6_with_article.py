"""Compare the re-run of the Fig. 6 experiment (output of reproduce_fig6.py) with Fig. 6 as printed.

The figure is read from the embedded raster image in the article PDF (2130 x 1029 px; Fig. 6 is the only
image of that size). The axes are calibrated from the tick marks (y: 0.24 ... 0.08, x: 0 ... 50), the two
curves are separated by colour (matplotlib default blue = TFGD, orange = Adam), and each curve is sampled
at the plot indices 0..49. One pixel corresponds to about 0.0002 in loss. Near indices 0-2 the curves are
steep and drawn with wide line ends, so the readout there is biased low by a few 1e-4.

usage: python compare_fig6_with_article.py --pdf ARTICLE.pdf [--results fig6_results.json] [--out fig6_comparison.json]
Requires PyMuPDF (fitz) and numpy.
"""
import argparse
import json

import fitz  # PyMuPDF
import numpy as np


def extract_fig6(pdf_path, size=(2130, 1029)):
    doc = fitz.open(pdf_path)
    for pno in range(len(doc)):
        for img in doc[pno].get_images(full=True):
            xref, w, h = img[0], img[2], img[3]
            if (w, h) == size:
                pix = fitz.Pixmap(doc, xref)
                if pix.alpha or pix.n != 3:
                    pix = fitz.Pixmap(fitz.csRGB, pix, 0)
                arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)[..., :3]
                return arr.astype(int), pno + 1
    raise SystemExit(f"no embedded image of size {size} found in {pdf_path}")


def groups(idx):
    out, cur = [], []
    for i in idx:
        if cur and i != cur[-1] + 1:
            out.append(np.mean(cur))
            cur = []
        cur.append(i)
    if cur:
        out.append(np.mean(cur))
    return out


def digitize(img):
    H, W, _ = img.shape
    dark = img.sum(axis=2) < 200
    left = int(np.argmax(dark.sum(axis=0)[: W // 3]))
    bottom = int(H // 2 + np.argmax(dark.sum(axis=1)[H // 2:]))
    yt = groups([y for y in range(H) if dark[y, left - 8:left - 1].all()])
    xt = groups([x for x in range(W) if dark[bottom + 2:bottom + 8, x].all()])
    yvals = np.array([0.24, 0.22, 0.20, 0.18, 0.16, 0.14, 0.12, 0.10, 0.08])
    xvals = np.array([0, 10, 20, 30, 40, 50])
    assert len(yt) == 9 and len(xt) == 6, (len(yt), len(xt))
    ay, by = np.polyfit(yt, yvals, 1)
    ax, bx = np.polyfit(xt, xvals, 1)
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    blue = (np.abs(r - 0x1f) < 60) & (np.abs(g - 0x77) < 50) & (np.abs(b - 0xb4) < 50) & (b > r + 60)
    orange = (np.abs(r - 0xff) < 50) & (np.abs(g - 0x7f) < 50) & (b < 90) & (r > g + 60)
    legend_x0 = int(np.polyval(np.polyfit(xvals, xt, 1), 44))
    mask_leg = np.zeros_like(blue)
    mask_leg[: int(np.polyval(np.polyfit(yvals, yt, 1), 0.205)), legend_x0:] = True
    out = {}
    for name, m in (("tfgd", blue & ~mask_leg), ("adam", orange & ~mask_leg)):
        xs, ys = [], []
        for x in range(left + 2, W):
            rows = np.nonzero(m[:, x])[0]
            if len(rows):
                xs.append(x)
                ys.append(rows.mean())
        ex = np.polyval([ax, bx], np.array(xs))
        ly = np.polyval([ay, by], np.array(ys))
        samples = []
        for e in range(50):
            sel = np.abs(ex - e) <= 0.25
            samples.append(float(np.median(ly[sel])) if sel.any() else float(np.interp(e, ex, ly)))
        out[name] = samples
    return out, float(abs(ay))  # loss units per pixel


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--results", default="fig6_results.json")
    ap.add_argument("--out", default="fig6_comparison.json")
    args = ap.parse_args()

    img, page = extract_fig6(args.pdf)
    fig, per_px = digitize(img)
    res = json.load(open(args.results))
    print(f"Fig. 6 read from page {page} of the article ({img.shape[1]} x {img.shape[0]} px; "
          f"1 px = {per_px:.5f} in loss)")
    print("Printed curves at indices 0, 19, 49: "
          f"TFGD {fig['tfgd'][0]:.4f} {fig['tfgd'][19]:.4f} {fig['tfgd'][49]:.4f}; "
          f"Adam {fig['adam'][0]:.4f} {fig['adam'][19]:.4f} {fig['adam'][49]:.4f}")
    comparison = {"page": page, "loss_per_pixel": per_px, "printed_curves": fig, "configs": {}}
    for cfg, c in res["configs"].items():
        row = {"desc": c["desc"], "seeds": c["seeds"]}
        line = f"config {cfg} ({c['desc']}; seeds {c['seeds']}):"
        for opt in ("tfgd", "adam"):
            L = np.array([r[opt] for r in c["runs"]]).mean(axis=0)
            n = min(len(L), 50)
            dev = L[:n] - np.array(fig[opt][:n])
            rmse_all = float(np.sqrt(np.mean(dev ** 2)))
            rmse_3 = float(np.sqrt(np.mean(dev[3:] ** 2)))
            maxdev_3 = float(np.max(np.abs(dev[3:])))
            row[opt] = {"rmse_idx0_%d" % (n - 1): rmse_all, "rmse_idx3_%d" % (n - 1): rmse_3,
                        "max_abs_dev_idx3_%d" % (n - 1): maxdev_3, "final_rerun": float(L[n - 1]),
                        "final_printed_same_index": fig[opt][n - 1]}
            line += (f"\n   {opt:4s}: RMSE vs printed curve {rmse_all:.5f} (indices 0-{n - 1}), "
                     f"{rmse_3:.5f} (indices 3-{n - 1}); max |dev| (3-{n - 1}) {maxdev_3:.5f}; "
                     f"re-run at index {n - 1}: {L[n - 1]:.5f}, printed: {fig[opt][n - 1]:.5f}")
        comparison["configs"][cfg] = row
        print(line)
    with open(args.out, "w") as f:
        json.dump(comparison, f, indent=1)
    print("wrote", args.out)


if __name__ == "__main__":
    main()
