"""
Evaluation of the tempered fractional update as DEFINED in the article (Eq. (2)), which the
released code does not implement:

    theta_{k+1} = theta_k - eta * sum_{j=0}^{k} |w_j| e^{-lambda j} grad L(theta_{k-j}),
    |w_j| = |binom(alpha, j)|  (absolute Grunwald-Letnikov weights, Definition 2.2).

The update is implemented exactly: every past gradient is stored (no truncation), so for the
k-th update the full sum over j = 0..k is formed. The weights sum to d = 2 - (1 - e^{-lambda})^alpha
(corrected Lemma 4.1), so for slowly varying gradients Eq. (2) behaves like gradient descent with
step eta * d; that comparator ("GD, matched total weight") is included.

Protocol: identical to reproduce_corrigendum_results.py (same data, split, model, initialisation,
30 seeds with a common initialisation per seed for Breast Cancer; 10 seeds for the two
additional benchmarks; eta = 0.1; accuracy and training loss after 100 epochs; convergence epoch
by the released criterion within 200 epochs).

Run:   python evaluate_eq2.py [--out DIR]     (writes DIR/tables/table_R4.tex, table_R5.tex and
                                               DIR/eq2_results.json; default ./corrigendum)
"""
import argparse
import json
import os

import numpy as np
from scipy.special import binom
from sklearn.datasets import load_breast_cancer, load_digits, make_classification
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

HERE = os.path.dirname(os.path.abspath(__file__))
_ap = argparse.ArgumentParser()
_ap.add_argument("--out", default=os.path.join(HERE, "corrigendum"))
OUTDIR = os.path.abspath(_ap.parse_args().out)
TAB = os.path.join(OUTDIR, "tables")
os.makedirs(TAB, exist_ok=True)

SEEDS = list(range(30))
SEEDS_EXTRA = list(range(10))
EPOCHS = 100
MAX_EPOCHS = 200
CONV_THRESHOLD = 1e-4
CONV_PATIENCE = 5
ETA = 0.1


def gl_abs(alpha, n):
    """|binom(alpha, j)|, j = 0..n-1, by the stable recursion |w_{j+1}| = |w_j| |j - alpha| / (j + 1)."""
    w = np.empty(n)
    w[0] = 1.0
    for j in range(n - 1):
        w[j + 1] = w[j] * abs(j - alpha) / (j + 1)
    return w


def d_corrected(alpha, lam):
    return 2 - (1 - np.exp(-lam)) ** alpha


# ----------------------------------------------------------------------------- optimisers
class TFGDEq2:
    """Exact Eq. (2): full gradient history, weights |binom(alpha,j)| e^{-lambda j}."""

    def __init__(self, alpha, lambd, lr=ETA, horizon=MAX_EPOCHS + 1):
        self.c = gl_abs(alpha, horizon) * np.exp(-lambd * np.arange(horizon))
        self.lr, self.hist = lr, []

    def update(self, params, grads):
        self.hist.append(np.array(grads, dtype=float, copy=True))
        k = len(self.hist) - 1
        # sum_{j=0}^{k} c_j g_{k-j}; hist[k-j] is the gradient j steps ago
        direction = sum(self.c[j] * self.hist[k - j] for j in range(k + 1))
        return params - self.lr * direction


class TFGDReleased:
    """Update rule of the released code (heavy-ball with beta = e^{-lambda}); alpha unused."""

    def __init__(self, alpha, lambd, lr=ETA):
        self.lambd, self.lr, self.S = lambd, lr, None

    def update(self, params, grads):
        if self.S is None:
            self.S = np.zeros_like(params)
        self.S = grads + np.exp(-self.lambd) * self.S
        return params - self.lr * self.S


class GD:
    def __init__(self, lr):
        self.lr = lr

    def update(self, params, grads):
        return params - self.lr * grads


# ----------------------------------------------------------------------------- model / training
def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def ce(y_true, y_pred):
    return -np.mean(y_true * np.log(y_pred + 1e-8) + (1 - y_true) * np.log(1 - y_pred + 1e-8))


def run(make_opt, Xtr, ytr, Xte, yte, seed, n_epochs, snapshot=EPOCHS):
    np.random.seed(seed)
    w = np.random.randn(Xtr.shape[1])
    b = np.random.randn()
    ow, ob = make_opt(), make_opt()
    losses, acc_snap, loss_snap = [], None, None
    for ep in range(1, n_epochs + 1):
        p = sigmoid(Xtr @ w + b)
        losses.append(ce(ytr, p))
        err = p - ytr
        dw = (Xtr.T @ err) / len(ytr)
        db = np.mean(err)
        w = ow.update(w, dw)
        b = ob.update(b, db)
        if ep == snapshot:
            acc_snap = accuracy_score(yte, (sigmoid(Xte @ w + b) > 0.5).astype(int))
            loss_snap = ce(ytr, sigmoid(Xtr @ w + b))
    return np.array(losses), acc_snap, loss_snap


def conv_epoch(losses):
    for ep in range(CONV_PATIENCE + 1, len(losses) + 1):
        if np.all(np.abs(np.diff(losses[ep - CONV_PATIENCE:ep])) < CONV_THRESHOLD):
            return ep
    return None


def pm(a, d=2):
    a = np.asarray(a, dtype=float)
    return f"{a.mean():.{d}f} $\\pm$ {a.std(ddof=1):.{d}f}"


# ----------------------------------------------------------------------------- self-checks
w_chk = gl_abs(0.6, 60)
assert np.allclose(w_chk, np.abs(binom(0.6, np.arange(60))), rtol=1e-12, atol=0)
assert abs(np.sum(gl_abs(0.6, 20000) * np.exp(-0.5 * np.arange(20000))) - d_corrected(0.6, 0.5)) < 1e-10
# Eq. (2) on a scalar quadratic, against a direct evaluation of the sum
opt, th, thetas = TFGDEq2(0.6, 0.5, lr=0.3), 1.0, [1.0]
for _ in range(30):
    th = float(opt.update(np.array(th), np.array(th)))
    thetas.append(th)
c = gl_abs(0.6, 40) * np.exp(-0.5 * np.arange(40))
th_d = [1.0]
for k in range(30):
    th_d.append(th_d[-1] - 0.3 * sum(c[j] * th_d[k - j] for j in range(k + 1)))
assert np.allclose(thetas, th_d, rtol=1e-12, atol=1e-14)
# Cross-check with the released recursion: with |w_j| replaced by 1 the exact-history update must
# reproduce S_k = g_k + e^{-lambda} S_{k-1} (corrected Lemma 5.1).
opt_h, opt_r = TFGDEq2(0.6, 0.5, lr=0.3), TFGDReleased(0.6, 0.5, lr=0.3)
opt_h.c = np.exp(-0.5 * np.arange(len(opt_h.c)))
th_h = th_r = np.array([1.0, -2.0])
for _ in range(30):
    th_h, th_r = opt_h.update(th_h, th_h), opt_r.update(th_r, th_r)
assert np.allclose(th_h, th_r, rtol=1e-12, atol=1e-14)
# Two steps by hand: theta_2 = theta_0 - eta (g_1 + alpha e^{-lambda} g_0) - eta g_0
o = TFGDEq2(0.6, 0.5, lr=1.0)
p2 = o.update(o.update(np.array([0.0]), np.array([1.0])), np.array([3.0]))
assert np.allclose(p2, -(1.0 + 3.0 + 0.6 * np.exp(-0.5) * 1.0))

# ----------------------------------------------------------------------------- Breast Cancer
data = load_breast_cancer()
X = StandardScaler().fit_transform(data.data)
Xtr, Xte, ytr, yte = train_test_split(X, data.target, test_size=0.2, random_state=42)
assert len(yte) == 114

results = {"protocol": __doc__, "breast_cancer": {}, "extra": {}}


def evaluate(key, mk):
    accs, fl, ce_ = [], [], []
    for s in SEEDS:
        losses, acc, lsnap = run(mk, Xtr, ytr, Xte, yte, s, MAX_EPOCHS)
        accs.append(acc * 100)
        fl.append(lsnap)
        ce_.append(conv_epoch(losses))
    results["breast_cancer"][key] = {"acc": accs, "final_loss": fl, "conv_epoch": ce_}
    conv = [x for x in ce_ if x is not None]
    print(f"{key:28s} acc {np.mean(accs):6.2f} +/- {np.std(accs, ddof=1):.2f}  loss {np.mean(fl):.4f}  "
          f"converged {len(conv)}/{len(SEEDS)}", flush=True)
    return accs, fl, ce_


rows = []
evaluate("gd_0.1", lambda: GD(ETA))
for lam in (0.1, 0.5, 1.0):
    for a in (0.3, 0.6, 0.9):
        d = d_corrected(a, lam)
        evaluate(f"eq2_{a}_{lam}", lambda a=a, lam=lam: TFGDEq2(a, lam))
        evaluate(f"gdmatch_{a}_{lam}", lambda d=d: GD(ETA * d))
        rows.append((a, lam, d))
    evaluate(f"released_{lam}", lambda lam=lam: TFGDReleased(0.6, lam))


def paired(k1, k2):
    a = np.array(results["breast_cancer"][k1]["acc"])
    b = np.array(results["breast_cancer"][k2]["acc"])
    diff = a - b
    return int(np.sum(diff > 0)), int(np.sum(diff == 0)), int(np.sum(diff < 0)), float(diff.mean())


def conv_txt(key):
    conv = [x for x in results["breast_cancer"][key]["conv_epoch"] if x is not None]
    return f"{len(conv)}/{len(SEEDS)}" + (f"; {np.median(conv):g}" if conv else "; --")


summary = {}
with open(os.path.join(TAB, "table_R4.tex"), "w", encoding="utf-8") as f:
    f.write("\\begin{tabular}{cccccccc}\n\\toprule\n")
    f.write("$\\alpha$ & $\\lambda$ & $\\dal$ & Eq.~(2): test acc.\\ (\\%) & Training loss & Converged & "
            "GD, $\\eta=0.1\\,\\dal$: test acc.\\ (\\%) & Eq.~(2) vs.\\ GD $0.1\\,\\dal$ \\\\\n")
    f.write(" & & & after 100 epochs & after 100 epochs & (runs; median) & after 100 epochs & "
            "(better/equal/worse) \\\\\n\\midrule\n")
    for a, lam, d in rows:
        k = f"eq2_{a}_{lam}"
        r = results["breast_cancer"][k]
        g = results["breast_cancer"][f"gdmatch_{a}_{lam}"]
        bt, eq, wo, md = paired(k, f"gdmatch_{a}_{lam}")
        summary[k] = {"d": d, "acc_mean": float(np.mean(r["acc"])), "acc_sd": float(np.std(r["acc"], ddof=1)),
                      "gdmatch_acc_mean": float(np.mean(g["acc"])), "vs_gdmatch": [bt, eq, wo, md]}
        f.write(f"{a} & {lam} & {d:.3f} & {pm(r['acc'])} & {pm(r['final_loss'], 3)} & {conv_txt(k)} & "
                f"{pm(g['acc'])} & {bt}/{eq}/{wo} \\\\\n")
    f.write("\\midrule\n")
    gd = results["breast_cancer"]["gd_0.1"]
    f.write(f"\\multicolumn{{3}}{{l}}{{GD, $\\eta=0.1$}} & {pm(gd['acc'])} & {pm(gd['final_loss'], 3)} & "
            f"{conv_txt('gd_0.1')} & & \\\\\n")
    for lam in (0.1, 0.5, 1.0):
        r = results["breast_cancer"][f"released_{lam}"]
        f.write(f"\\multicolumn{{3}}{{l}}{{Released recursion, $\\lambda={lam}$}} & {pm(r['acc'])} & "
                f"{pm(r['final_loss'], 3)} & {conv_txt(f'released_{lam}')} & & \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}\n")
results["summary"] = summary

for lam in (0.1, 0.5, 1.0):
    print(f"lambda={lam}: Eq.(2) vs GD 0.1 (better/equal/worse, mean diff):",
          {a: paired(f"eq2_{a}_{lam}", "gd_0.1") for a in (0.3, 0.6, 0.9)})
    print(f"lambda={lam}: Eq.(2) vs released recursion:",
          {a: paired(f"eq2_{a}_{lam}", f"released_{lam}") for a in (0.3, 0.6, 0.9)})

# ----------------------------------------------------------------------------- additional benchmarks
X_hd, y_hd = make_classification(n_samples=2000, n_features=1000, n_informative=50, n_redundant=0,
                                 n_repeated=0, n_classes=2, flip_y=0.01, class_sep=1.0, random_state=42)
digits = load_digits()
y_dg = (digits.target == 0).astype(int)
A_X, L_X = 0.7, 0.3
d_x = d_corrected(A_X, L_X)
EXTRA = [
    ("eq2", rf"Eq.~(2), $\alpha={A_X}$, $\lambda={L_X}$ ($d={d_x:.3f}$)", lambda: TFGDEq2(A_X, L_X)),
    ("gdmatch", rf"GD, $\eta=0.1\,d={ETA * d_x:.3f}$", lambda: GD(ETA * d_x)),
    ("gd01", r"GD, $\eta=0.1$", lambda: GD(ETA)),
    ("released", rf"Released recursion, $\lambda={L_X}$", lambda: TFGDReleased(A_X, L_X)),
]


def prep(Xr, yr):
    Xs = StandardScaler().fit_transform(Xr)
    return train_test_split(Xs, yr, test_size=0.2, random_state=42)


extra = {}
for dname in ("hd", "digits"):
    extra[dname] = {k: [] for k, _, _ in EXTRA}
    for s in SEEDS_EXTRA:
        if dname == "hd":
            a_tr, a_te, b_tr, b_te = prep(X_hd, y_hd)
        else:
            noise = np.random.default_rng(10_000 + s).normal(scale=4.0, size=digits.data.shape)
            a_tr, a_te, b_tr, b_te = prep(digits.data + noise, y_dg)
        for k, _, mk in EXTRA:
            _, acc, _ = run(mk, a_tr, b_tr, a_te, b_te, s, EPOCHS)
            extra[dname][k].append(acc * 100)
    print(dname, {k: f"{np.mean(v):.2f}+/-{np.std(v, ddof=1):.2f}" for k, v in extra[dname].items()}, flush=True)
results["extra"] = extra

with open(os.path.join(TAB, "table_R5.tex"), "w", encoding="utf-8") as f:
    f.write("\\begin{tabular}{lcc}\n\\toprule\n")
    f.write("Optimizer & High-dim.\\ synthetic (1000 D) & Noisy digits (0 vs.\\ rest) \\\\\n\\midrule\n")
    for k, label, _ in EXTRA:
        f.write(f"{label} & {pm(extra['hd'][k])} & {pm(extra['digits'][k])} \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}\n")

with open(os.path.join(OUTDIR, "eq2_results.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, indent=1, default=float)
print("written:", TAB, OUTDIR)
