"""
Independent checks of the points raised in the technical note on
O. Naifar, "Tempered fractional gradient descent: Theory, algorithms, and
robust learning applications", Neural Networks 193 (2026) 108005.

Run:   python verify_note_claims.py > verification_output.txt
Needs: numpy, scipy, scikit-learn  (no GPU, about 1 minute)

Sections
  1. Theorem 4.1 counterexample (theta^2/2)
  2. Definition 2.2 vs Lemma 4.1: which coefficients have generating fn (1-z)^-alpha
  3. Eq. (21)/Table 1 recursion: what weights it actually produces
  4. Released code (TFGD.txt, commit 1a6d0b5): alpha-independence of the sweep
  5. Released code: TFGD vs SGD vs SGD with matched effective step size
  6. Lemma 4.2 bound vs its own j=0 term
  7. Theorem 4.2 proof: sum of eta_k^2 with eta_k = eta0 / k^(alpha/2); the example showing that
     Theorem 4.2 is false
  8. Arithmetic consistency of reported mean +/- SD (5 runs) with the test-set size: exact enumeration,
     rounding and truncation, exact and four-decimal accuracies, n = 114, 56, 57, 58; coincidence of
     the means with single-run values
  9. Same check for Table 7 (single runs)
 10. Lemma 5.2, Remark 2, Section 5 and Fig. 1: elementary checks
 11. Corrected Theorems 4.1 and 4.2: constants d and D, the identity of Lemma C1, and the bounds on
     convex, non-convex and noisy test problems, for Eq. (2) and for the released recursion; the
     example showing that E[xi_k | F_k] = 0 cannot be weakened to E[xi_k] = 0; the tuned step
 12. Further errors in the published proofs: Watson-lemma inequality (Lemma 4.1), Eqs. (15)-(16)
     (Lemma 4.2), and the lag series of the proof of Theorem 4.1
"""
import itertools
import math

import numpy as np
from scipy.special import binom, gamma, poch
from sklearn.datasets import load_breast_cancer
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

np.set_printoptions(precision=6, suppress=True, linewidth=120)


def hdr(title):
    print("\n" + "=" * 78 + "\n" + title + "\n" + "=" * 78)


def d_paper(a, lam):
    """Alignment coefficient of Lemma 4.1: (1 - e^-lambda)^-alpha."""
    return (1.0 - np.exp(-lam)) ** (-a)


def abs_gl(a, J):
    """|binom(alpha, j)|, j = 0..J-1  (the weights of Definition 2.2)."""
    return np.abs(binom(a, np.arange(J)))


def frac_sum(a, J):
    """Coefficients of (1 - z)^(-alpha): (alpha)_j / j!  (fractional summation).
    Computed by the stable recursion c_0 = 1, c_j = c_{j-1} (j - 1 + alpha) / j."""
    c = np.ones(J)
    for j in range(1, J):
        c[j] = c[j - 1] * (j - 1 + a) / j
    return c


# --------------------------------------------------------------------------
hdr("1. Theorem 4.1 counterexample: L(theta)=theta^2/2, theta0=1, L=1, theta*=0, eta=1/L=1")
print("K * LHS of Eq.(7) >= L(theta0) - L* = 0.5 for every K (all terms are >= 0).")
print("K * RHS of Eq.(7) = 1/(2d) + C*K*exp(-lambda*K)/(lambda*d)  ->  1/(2d) as K -> inf.")
print("So the theorem fails for large K whenever d > 1.\n")
print(f"{'alpha':>6} {'lambda':>7} {'d_alpha,lambda':>15} {'lim K*RHS':>10}  violated?")
for a in (0.1, 0.3, 0.6, 0.9, 0.99):
    for lam in (0.01, 0.1, 0.5, 1.0, 5.0):
        d = d_paper(a, lam)
        print(f"{a:6.2f} {lam:7.2f} {d:15.6f} {1 / (2 * d):10.6f}  {'YES' if 1 / (2 * d) < 0.5 else 'no'}")

grid_a = np.linspace(0.001, 0.999, 999)
grid_l = np.logspace(-4, 2, 1000)
A, Lm = np.meshgrid(grid_a, grid_l)
# d - 1 computed without cancellation (d itself rounds to 1 in float64 for large lambda)
print(f"\nmin of d - 1 over alpha in [0.001, 0.999], lambda in [1e-4, 100]: published d = (1-e^-lambda)^-alpha: "
      f"{np.expm1(-A * np.log1p(-np.exp(-Lm))).min():.3e};  corrected d = 2-(1-e^-lambda)^alpha: "
      f"{-np.expm1(A * np.log1p(-np.exp(-Lm))).min():.3e}  (both > 0, so d > 1)")


def run_on_quadratic(weights_fn, a, lam, K, eta=1.0):
    """theta_{k+1} = theta_k - eta * sum_j w_j e^{-lambda j} grad(theta_{k-j}), grad = theta."""
    th = [1.0]
    w = weights_fn(a, K + 1) * np.exp(-lam * np.arange(K + 1))
    for k in range(K):
        hist = np.array(th[::-1])  # theta_k, theta_{k-1}, ..., theta_0
        step = float(np.dot(w[: k + 1], hist))
        th.append(th[-1] - eta * step)
        if not np.isfinite(th[-1]) or abs(th[-1]) > 1e150:
            break
    return np.array(th[:K])


def run_code_recursion(a, lam, K, eta=1.0):
    """Exactly the released update: S = grad + e^-lambda * S ; theta -= eta * S."""
    th, S, out = 1.0, 0.0, []
    for _ in range(K):
        out.append(th)
        S = th + np.exp(-lam) * S
        th = th - eta * S
    return np.array(out)


K, C = 200, 1e6
print(f"\nSimulated trajectories, K={K}, any constant C (here C={C:g}):")
print(f"{'alpha':>6} {'lambda':>7} {'variant':<34} {'K*LHS':>12} {'K*RHS':>10}")
for a, lam in ((0.6, 0.5), (0.3, 0.5), (0.9, 0.5), (0.6, 0.1), (0.6, 1.0)):
    d = d_paper(a, lam)
    krhs = 1 / (2 * d) + C * K * np.exp(-lam * K) / (lam * d)
    for name, traj in (
        ("released code recursion", run_code_recursion(a, lam, K)),
        ("Eq.(2), |binom(alpha,j)| weights", run_on_quadratic(abs_gl, a, lam, K)),
        ("Eq.(2), (1-z)^-alpha coefficients", run_on_quadratic(frac_sum, a, lam, K)),
    ):
        with np.errstate(over="ignore", invalid="ignore"):
            klhs = float(np.sum(traj ** 2 / 2))
        if not np.isfinite(klhs) or len(traj) < K:
            print(f"{a:6.2f} {lam:7.2f} {name:<34} {'diverges':>12} {krhs:10.4f}  VIOLATED")
        else:
            print(f"{a:6.2f} {lam:7.2f} {name:<34} {klhs:12.4g} {krhs:10.4f}  {'VIOLATED' if klhs > krhs else 'ok'}")

print("\nKnown result for the implemented recursion (heavy-ball, beta = e^-lambda), cited but not restated")
print("in the corrigendum; numerical sanity check only:")
print("Ghadimi et al. (2015, Thm 1): for eta in (0, (1-beta)/L], with theta_bar_K = mean(theta_0..theta_K),")
print("  L(theta_bar_K) - L* <= ||theta0-theta*||^2 / (2(K+1)) * (L beta/(1-beta) + (1-beta)/eta)")
rng_q = np.random.default_rng(1)
Q = rng_q.standard_normal((20, 20))
H = Q.T @ Q / 20 + 0.0 * np.eye(20)  # convex quadratic, possibly ill-conditioned
Lq = np.linalg.eigvalsh(H).max()
x0 = rng_q.standard_normal(20)
for lam in (0.1, 0.5, 1.0):
    beta = np.exp(-lam)
    eta = (1 - beta) / Lq
    x, S, xs = x0.copy(), np.zeros(20), []
    for _ in range(501):
        xs.append(x.copy())
        S = H @ x + beta * S
        x = x - eta * S
    worst = 0.0
    for Kk in (10, 50, 100, 500):
        xb = np.mean(xs[: Kk + 1], axis=0)
        gap = 0.5 * xb @ H @ xb
        bound = (x0 @ x0) / (2 * (Kk + 1)) * (Lq * beta / (1 - beta) + (1 - beta) / eta)
        worst = max(worst, gap / bound)
    print(f"  lambda={lam}: max over K of gap/bound = {worst:.4f}  ({'holds' if worst <= 1 else 'FAILS'})")

# --------------------------------------------------------------------------
hdr("2. Definition 2.2 vs Lemma 4.1 (generating functions)")
a = 0.6
J = 6
print(f"alpha = {a}")
print("j                       :", np.arange(J))
print("|binom(alpha,j)| (Def2.2):", abs_gl(a, J))
print("coeffs of (1-z)^-alpha   :", frac_sum(a, J))
print(f"lag 2: alpha(1-alpha)/2 = {a * (1 - a) / 2:.6f},  alpha(1+alpha)/2 = {a * (1 + a) / 2:.6f}")
z = 0.37
Jbig = 20000
print(f"\nAt z = {z}:  sum |binom(alpha,j)| z^j = {np.sum(abs_gl(a, Jbig) * z ** np.arange(Jbig)):.10f}")
print(f"            2 - (1-z)^alpha           = {2 - (1 - z) ** a:.10f}")
print(f"            (1-z)^-alpha  [Eq. (6)]   = {(1 - z) ** (-a):.10f}")
print("\nTempered sums sum_j |binom(alpha,j)| e^{-lambda j}  vs  d of Lemma 4.1:")
for a, lam in ((0.3, 0.5), (0.6, 0.1), (0.6, 0.5), (0.6, 1.0), (0.9, 0.5)):
    s = np.sum(abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig)))
    print(f"  alpha={a}, lambda={lam}: actual sum = {s:.6f}"
          f"  = 2-(1-e^-l)^a = {2 - (1 - np.exp(-lam)) ** a:.6f};  Lemma 4.1 d = {d_paper(a, lam):.6f}")
print("\nTail behaviour used in the proof of Lemma 4.1 (j = 1000):")
a, j = 0.6, 1000
print(f"  |binom(alpha,j)|      = {abs_gl(a, j + 1)[-1]:.3e}   ~ alpha j^-(1+alpha)/Gamma(1-alpha) = {a * j ** (-1 - a) / gamma(1 - a):.3e}")
print(f"  (1-z)^-alpha coeff    = {frac_sum(a, j + 1)[-1]:.3e}   ~ j^(alpha-1)/Gamma(alpha)          = {j ** (a - 1) / gamma(a):.3e}")
print("  -> the proof sums one sequence but bounds the tail of the other.")

print("\nCorrected tail bound (used in the corrigendum):")
print("  R_k = sum_{j>k} |binom(a,j)| e^{-l j} <= a e^{-l(k+1)} / ((k+1)^(1+a) (1-e^{-l}))")
print("  (uses |binom(a,j)| <= a j^-(1+a), j >= 1)")
for a in (0.05, 0.3, 0.6, 0.9, 0.99):
    w = abs_gl(a, 100000)
    jj = np.arange(1, 100000)
    print(f"  alpha={a}: max_j |binom(a,j)| j^(1+a) / a = {np.max(w[1:] * jj ** (1 + a)) / a:.6f}  (<= 1 required)")
for a, lam in ((0.3, 0.5), (0.6, 0.1), (0.6, 0.5), (0.9, 1.0), (0.01, 0.01), (0.99, 2.0)):
    w = abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig))
    worst = 0.0
    for k in range(0, 400):
        Rk = np.sum(w[k + 1:])
        bound = a * np.exp(-lam * (k + 1)) / ((k + 1) ** (1 + a) * (1 - np.exp(-lam)))
        if bound < 1e-250:  # both sides underflow in double precision beyond this point
            break
        worst = max(worst, Rk / bound)
    print(f"  alpha={a}, lambda={lam}: max_(k<400) R_k / bound = {worst:.4f}  ({'holds' if worst <= 1 else 'FAILS'})")
a, lam, k = 0.6, 0.5, 20
w = abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig))
print(f"  example (alpha, lambda, k) = (0.6, 0.5, 20): R_k = {np.sum(w[k + 1:]):.3e}, "
      f"bound = {a * np.exp(-lam * (k + 1)) / ((k + 1) ** (1 + a) * (1 - np.exp(-lam))):.3e}")
print("Lower bounds (corrigendum Section C4): keeping the factor 1-a (i = 1) of the product in Eq. (C1.1) and using")
print("1-a/i >= 1-1/i for 2 <= i <= j-1 (telescoping), |binom(a,j)| >= a(1-a)/(j(j-1)) for j >= 2; with |binom(a,1)| = a,")
print("R_k >= |binom(a,k+1)| e^{-l(k+1)} >= a(1-a) e^{-l(k+1)}/(k+1)^2 for k >= 0 (exponential decay only)")
for a in (0.05, 0.3, 0.6, 0.9, 0.99):
    w = abs_gl(a, 100000)
    jj = np.arange(2, 100000)
    print(f"  alpha={a}: min_(2<=j<1e5) |binom(a,j)| j(j-1) / (a(1-a)) = {np.min(w[2:] * jj * (jj - 1)) / (a * (1 - a)):.6f}"
          f"  (>= 1 required)")
for a, lam in ((0.3, 0.5), (0.6, 0.1), (0.6, 0.5), (0.9, 1.0), (0.01, 0.01), (0.99, 2.0)):
    w = abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig))
    worst = np.inf
    for k in range(0, 400):
        low = a * (1 - a) * np.exp(-lam * (k + 1)) / (k + 1) ** 2
        if low < 1e-250:
            break
        worst = min(worst, np.sum(w[k + 1:]) / low)
    print(f"  alpha={a}, lambda={lam}: min_(k<400) R_k / lower bound = {worst:.4f}  ({'holds' if worst >= 1 else 'FAILS'})")
print("\nProof of Theorem 4.1, error (iv): Eq. (1) with a constant gradient g gives lambda^(alpha-1) g, whereas")
print("the weights of Eq. (2) up to lag k sum to (1, 1.364, 1.408, ...) -> d:")
a, lam = 0.6, 0.5
ps = np.cumsum(abs_gl(a, 6) * np.exp(-lam * np.arange(6)))
print(f"  (0.6, 0.5): lambda^(alpha-1) = {lam ** (a - 1):.4f};  partial sums k=0..5: "
      + ", ".join(f"{p:.3f}" for p in ps) + f";  d = {2 - (1 - np.exp(-lam)) ** a:.4f}")

# --------------------------------------------------------------------------
hdr("3. Recursion of Eq. (21) / Table 1: S_k = |w_0| g_k + e^-lambda S_{k-1}, |w_0| = 1")
rng = np.random.default_rng(0)
Kr = 400
g = rng.standard_normal(Kr + 1)
for a, lam in ((0.1, 0.5), (0.6, 0.5), (0.9, 0.5)):
    S = 0.0
    for k in range(Kr + 1):
        S = binom(a, 0) * g[k] + np.exp(-lam) * S
    j = np.arange(Kr + 1)
    geo = np.sum(np.exp(-lam * j) * g[::-1])
    tfd_abs = np.sum(abs_gl(a, Kr + 1) * np.exp(-lam * j) * g[::-1])
    tfd_sum = np.sum(frac_sum(a, Kr + 1) * np.exp(-lam * j) * g[::-1])
    print(f"alpha={a}: recursion S_k = {S:+.12f} | sum e^-lj g = {geo:+.12f} | "
          f"sum |binom| e^-lj g = {tfd_abs:+.6f} | sum (1-z)^-a coeff e^-lj g = {tfd_sum:+.6f}")
print("-> The recursion reproduces the geometric weights e^{-lambda j} exactly and is the same for every alpha.")
print("   Its gap to either fractional sum is a fixed per-lag weight difference (lag 1: 1 vs alpha),")
print("   so it does not shrink like O(e^{-lambda k}/k^{1+alpha}) as Lemma 5.1 states.")

# --------------------------------------------------------------------------
hdr("4. Released code, sensitivity sweep (TFGD.txt lines 112-217, commit 1a6d0b5), seeded")
LEARNING_RATE = 0.1
MAX_EPOCHS = 200
CONV_THRESHOLD = 1e-4
CONV_PATIENCE = 5

data = load_breast_cancer()
X, y = data.data, data.target
X = StandardScaler().fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"n_train = {len(y_train)}, n_test = {len(y_test)}")


def sigmoid(zz):
    return 1 / (1 + np.exp(-zz))


def cross_entropy_loss(y_true, y_pred):
    return -np.mean(y_true * np.log(y_pred + 1e-8) + (1 - y_true) * np.log(1 - y_pred + 1e-8))


class TFGDOptimizer:  # verbatim from TFGD.txt lines 146-157
    def __init__(self, alpha, lambd):
        self.alpha = alpha
        self.lambd = lambd
        self.S = None

    def update(self, params, grads):
        if self.S is None:
            self.S = np.zeros_like(params)
        self.S = grads + np.exp(-self.lambd) * self.S
        return params - LEARNING_RATE * self.S


class HeavyBall:  # PyTorch SGD(momentum=beta, dampening=0) form: v = beta v + g; p -= lr v
    def __init__(self, beta, lr):
        self.beta, self.lr, self.v = beta, lr, None

    def update(self, params, grads):
        if self.v is None:
            self.v = np.zeros_like(params)
        self.v = self.beta * self.v + grads
        return params - self.lr * self.v


class PlainGD:
    def __init__(self, lr):
        self.lr = lr

    def update(self, params, grads):
        return params - self.lr * grads


class LogisticRegression:  # verbatim from TFGD.txt lines 160-172
    def __init__(self, dim):
        self.w = np.random.randn(dim)
        self.b = np.random.randn()

    def forward(self, Xx):
        return sigmoid(Xx @ self.w + self.b)

    def grads(self, Xx, y_true, y_pred):
        err = y_pred - y_true
        dw = (Xx.T @ err) / len(y_true)
        db = np.mean(err)
        return dw, db


def train_and_evaluate(make_opt, max_epochs=MAX_EPOCHS, early_stop=True):
    """TFGD.txt lines 175-202, with the optimiser factory made a parameter."""
    model = LogisticRegression(X_train.shape[1])
    opt_w, opt_b = make_opt(), make_opt()
    losses = []
    conv_epoch = max_epochs
    for epoch in range(1, max_epochs + 1):
        y_pred = model.forward(X_train)
        losses.append(cross_entropy_loss(y_train, y_pred))
        dw, db = model.grads(X_train, y_train, y_pred)
        model.w = opt_w.update(model.w, dw)
        model.b = opt_b.update(model.b, db)
        if early_stop and epoch > CONV_PATIENCE:
            if np.all(np.abs(np.diff(losses[-CONV_PATIENCE:])) < CONV_THRESHOLD):
                conv_epoch = epoch
                break
    acc = accuracy_score(y_test, (model.forward(X_test) > 0.5).astype(int))
    return acc, conv_epoch, model


print("\nSame seed (0) for every alpha, lambda = 0.5:")
ref = None
for a in np.linspace(0.1, 1.0, 10):
    np.random.seed(0)
    acc, ep, m = train_and_evaluate(lambda: TFGDOptimizer(a, 0.5))
    params = np.append(m.w, m.b)
    if ref is None:
        ref = params
    print(f"  alpha={a:.1f}: acc={acc:.4f}  conv_epoch={ep}  max|params - params(alpha=0.1)| = {np.max(np.abs(params - ref)):.1e}")

np.random.seed(0)
_, _, m_tfgd = train_and_evaluate(lambda: TFGDOptimizer(0.6, 0.5))
np.random.seed(0)
_, _, m_hb = train_and_evaluate(lambda: HeavyBall(np.exp(-0.5), LEARNING_RATE))
print(f"\nReleased TFGD(alpha=0.6, lambda=0.5) vs heavy-ball momentum beta=e^-0.5={np.exp(-0.5):.4f}, same seed:")
print(f"  max |param difference| = {np.max(np.abs(np.append(m_tfgd.w, m_tfgd.b) - np.append(m_hb.w, m_hb.b))):.1e}")

print("\nSeeded stand-ins (seeds 1000-1499) for the unseeded runs of the released script, alpha=0.6, lambda=0.5:")
accs, eps_ = [], []
for s in range(500):
    np.random.seed(1000 + s)
    acc, ep, _ = train_and_evaluate(lambda: TFGDOptimizer(0.6, 0.5))
    accs.append(acc)
    eps_.append(ep)
accs = np.array(accs)
print(f"  test accuracy: min {accs.min():.4f}  max {accs.max():.4f}  mean {accs.mean():.4f}  sd {accs.std(ddof=1):.4f}")
vals, cnts = np.unique(np.round(accs * 114).astype(int), return_counts=True)
print("  frequency of each accuracy: " + ", ".join(f"{v}/114 = {100 * v / 114:.2f}%: {c}" for v, c in zip(vals, cnts)))
print(f"  convergence epoch: min {min(eps_)}  max {max(eps_)}  (published Fig. 5 panel (a) spans 0.938-0.991)")
n_low = int(np.sum(np.round(accs * 114).astype(int) == 107))
print("  -> alpha does not enter the update (bit-identical parameters above), so the variation over alpha in the")
print(f"     published code-generated figure is seed noise; its lowest value, 107/114 = 0.9386, occurs in {n_low} of these 500 runs.")

# --------------------------------------------------------------------------
hdr("5. Released code, main protocol (100 epochs, lr 0.1): seeds 0-29 (same as corrigendum Table R1)")
eff_lr = LEARNING_RATE / (1 - np.exp(-0.5))
rows = (
    ("TFGD as released (alpha=0.6, lambda=0.5)", lambda: TFGDOptimizer(0.6, 0.5)),
    ("plain GD, lr=0.1", lambda: PlainGD(0.1)),
    (f"plain GD, lr={eff_lr:.4f} (= 0.1/(1-e^-0.5))", lambda: PlainGD(eff_lr)),
    ("heavy-ball beta=0.9, lr=0.1", lambda: HeavyBall(0.9, 0.1)),
)
for name, mk in rows:
    res = []
    for s in range(30):
        np.random.seed(s)
        res.append(train_and_evaluate(mk, max_epochs=100, early_stop=False)[0])
    res = np.array(res) * 100
    print(f"  {name:<46} acc = {res.mean():6.2f} +/- {res.std(ddof=1):4.2f} %   [min {res.min():.2f}, max {res.max():.2f}]")
print("  Published Table 2: TFGD 98.25 +/- 0.31 %, SGD 92.11 +/- 0.87 %.")

# --------------------------------------------------------------------------
hdr("6. Lemma 4.2: sum_j |w_j|^2 e^{-2 lambda j} <= Gamma(1+2a) / ((2 lambda)^{2a} Gamma(1+a)^2)")
print("The j = 0 term alone equals |w_0|^2 = 1, so the bound fails whenever the RHS < 1.")
for a in (0.3, 0.6, 0.9):
    for lam in (0.1, 0.5, 1.0, 2.0):
        rhs = gamma(1 + 2 * a) / ((2 * lam) ** (2 * a) * gamma(1 + a) ** 2)
        lhs_abs = np.sum(abs_gl(a, 5000) ** 2 * np.exp(-2 * lam * np.arange(5000)))
        lhs_sum = np.sum(frac_sum(a, 5000) ** 2 * np.exp(-2 * lam * np.arange(5000)))
        bad = "FALSE" if min(lhs_abs, lhs_sum) > rhs else "holds"
        print(f"  alpha={a}, lambda={lam}: RHS={rhs:7.4f}  LHS(|binom|)={lhs_abs:7.4f}  LHS((1-z)^-a)={lhs_sum:7.4f}  -> {bad}")

from scipy.special import hyp2f1  # noqa: E402

print("\nCorrected statement (used in the corrigendum):")
print("  sum_j binom(a,j)^2 z^j = 2F1(-a,-a;1;z)  <= min{ Gamma(1+2a)/Gamma(1+a)^2 (Gauss, z=1),  1 + a^2 z/(1-z) }"
      "   (z = e^{-2 lambda})")
for a in (0.3, 0.6, 0.9):
    gauss = gamma(1 + 2 * a) / gamma(1 + a) ** 2
    for lam in (0.01, 0.1, 0.5, 1.0):
        zz = np.exp(-2 * lam)
        lhs = np.sum(abs_gl(a, 200000) ** 2 * zz ** np.arange(200000))
        simple = 1 + a * a * zz / (1 - zz)
        print(f"  alpha={a}, lambda={lam}: series={lhs:.10f}  2F1={hyp2f1(-a, -a, 1, zz):.10f}  "
              f"Gauss bound={gauss:.6f}  simple bound={simple:.6f}  "
              f"({'holds' if lhs <= min(gauss, simple) + 1e-12 else 'FAILS'})")
print(f"  check of Gauss's theorem at alpha=0.6: sum_j binom(0.6,j)^2 (2e6 terms) = "
      f"{np.sum(abs_gl(0.6, 2000000) ** 2):.10f},  Gamma(2.2)/Gamma(1.6)^2 = {gamma(2.2) / gamma(1.6) ** 2:.10f}")

from scipy.integrate import quad  # noqa: E402

print("\nEqs. (14) and (15) of the proof, evaluated at z = e^{-2 lambda}, against the true sum:")
print("  Eq. (14): (1-z)^(-2a) 2F1(a, a; 1; z^2/(1-z)^2)")
print("  Eq. (15): Gamma(1+2a)/Gamma(1+a)^2 * int_0^1 t^(a-1) (1-t)^(a-1) e^(-2 lambda t) dt")
for a, lam in ((0.6, 0.5), (0.6, 1.0)):
    zz = np.exp(-2 * lam)
    true_sum = hyp2f1(-a, -a, 1, zz)
    eq14 = (1 - zz) ** (-2 * a) * hyp2f1(a, a, 1, zz ** 2 / (1 - zz) ** 2)
    integral = quad(lambda t: np.exp(-2 * lam * t), 0, 1, weight="alg", wvar=(a - 1, a - 1))[0]
    eq15 = gamma(1 + 2 * a) / gamma(1 + a) ** 2 * integral
    print(f"  alpha={a}, lambda={lam}: true sum = {true_sum:.5f}   Eq.(14) = {eq14:.5f}   Eq.(15) = {eq15:.5f}"
          f"   -> {'both incorrect' if min(abs(eq14 - true_sum), abs(eq15 - true_sum)) > 1e-3 else 'CHECK'}")

# --------------------------------------------------------------------------
hdr("7. Theorem 4.2 proof: 'sum eta_k^2 <= C eta0^2' with eta_k = eta0 / k^(alpha/2)")
for a in (0.3, 0.6, 0.9):
    parts = [np.sum(np.arange(1, Kk + 1, dtype=float) ** (-a)) for Kk in (10 ** 2, 10 ** 4, 10 ** 6)]
    print(f"  alpha={a}: sum_(k<=K) k^-alpha for K=1e2,1e4,1e6: " + ", ".join(f"{p:,.1f}" for p in parts) + "  (diverges)")
print("Dividing the final inequality of the proof by K: first term ~ K^(alpha/2 - 1), claimed rate K^(-alpha).")
for a in (0.3, 2 / 3, 0.9):
    Kk = 1e6
    print(f"  alpha={a:.3f}: K^(alpha/2-1) / K^(-alpha) at K=1e6 = {Kk ** (a / 2 - 1) / Kk ** (-a):.3g}"
          f"  ({'not O(K^-alpha)' if a > 2 / 3 + 1e-12 else 'within O(K^-alpha)'})")
print("Averaged noise term (C sigma^2 / K) sum_{k=1}^K e^{-2 lambda k} >= C sigma^2 e^{-2 lambda} / K, i.e. order 1/K.")
print("\nTheorem 4.2 is false (corrigendum Section C2). Example: L(theta) = theta^2/2 (convex, L = 1, L* = 0), theta_0 = 0,")
print("xi_k = xi_0 for every k, xi_0 = +sigma or -sigma with probability 1/2, so that E[xi_k] = 0 and E xi_k^2 = sigma^2 (the")
print("assumptions of its proof). With eta_k = eta0 k^(-alpha/2) (eta0 at k = 0), Eq. (2) gives theta_k = c_k xi_0, where")
print("c_0 = 0 and c_{k+1} = c_k - eta_k sum_{j<=k} a_j (c_{k-j} + 1) is deterministic, so E[L(theta_k) - L*] = c_k^2 sigma^2/2.")
print("The right side of Eq. (17), C_1/k^alpha + C_2 sigma^2 e^(-2 lambda k), tends to 0 for any constants; the left side")
print("tends to sigma^2/2 (theta_k -> -xi_0). Weights a_j < e^(-700) are dropped (below double precision):")
for a, lam in ((0.6, 0.5), (0.3, 0.1), (0.9, 1.0)):
    J7 = int(np.ceil(700 / lam))
    w7 = abs_gl(a, J7) * np.exp(-lam * np.arange(J7))
    W7 = np.cumsum(w7)
    for eta0 in (0.05, 0.2, 1.0):
        c7 = np.zeros(20001)
        for k in range(20000):
            m = min(k + 1, J7)
            c7[k + 1] = c7[k] - eta0 * max(k, 1) ** (-a / 2) * (np.dot(w7[:m], c7[k::-1][:m]) + W7[m - 1])
        print(f"  alpha={a}, lambda={lam}, eta0={eta0}: E[L(theta_k) - L*]/sigma^2 at k = 1e2, 1e3, 1e4, 2e4: "
              + ", ".join(f"{c7[k] ** 2 / 2:.6f}" for k in (100, 1000, 10000, 20000)))

# --------------------------------------------------------------------------
hdr("8. Can the reported mean +/- SD be the result of 5 runs on the test set?")
print("Accuracy on n test samples is 100 k/n % (k correct). For five runs with counts k_1..k_5, let")
print("S = sum k_i and M = sum_{i<j} (k_i - k_j)^2. The mean is 20 S/n %, the sample SD (ddof 1) is")
print("(100/n) sqrt(M/20) % and the population SD (ddof 0) is (100/n) sqrt(M/25) %. A reported value X")
print("(two decimals) is matched under 'rounding' if the exact value lies in [X - 0.005, X + 0.005) and")
print("under 'truncation' if it lies in [X, X + 0.01). All comparisons are exact integer arithmetic, and")
print("every 5-tuple of counts in [0, n] is covered. n = 114 (80/20 split, as in the code) and n = 56, 57,")
print("58 (the possible test-set sizes of the 80/10/10 split stated in Section 6).\n")
reported = [
    ("Table 2/3/6  TFGD (0.6,0.5)", 98.25, 0.31),
    ("Table 2/4    SGD", 92.11, 0.87),
    ("Table 3      Adam", 69.30, 3.15),
    ("Table 3      RMSprop", 92.98, 0.92),
    ("Table 4      SGDM", 94.74, 0.42),
    ("Table 4      Zhou-FGD", 95.61, 0.58),
    ("Table 4      Shin-FAdam", 96.49, 0.37),
    ("Table 6      (0.3,0.5)", 97.81, 0.42),
    ("Table 6      (0.6,0.1)", 98.72, 0.28),
    ("Table 6      (0.6,1.0)", 96.33, 0.49),
    ("Table 6      (0.9,0.5)", 98.40, 0.33),
]
# Every sorted 5-tuple of counts is a shift k_i = s + t_i of a sorted tuple t with t_1 = 0. A tuple with
# M <= 40^2 has max - min <= 40, so the tuples t with entries in [0, 40] cover every M up to 1600.
T0 = np.array([(0,) + c for c in itertools.combinations_with_replacement(range(41), 4)], dtype=np.int64)
T0_sum, T0_max = T0.sum(1), T0[:, -1]
T0_M = sum((T0[:, i] - T0[:, j]) ** 2 for i in range(5) for j in range(i + 1, 5))
M_LIMIT = 40 ** 2
NS = (114, 56, 57, 58)


def sd_match(M, n, x, ddof, mode):
    """Exact test that the SD of five runs with statistic M matches x hundredths of a percent."""
    c = 20 if ddof == 1 else 25
    v = 10 ** 8 * M  # (100 * SD in %)^2 * c * n^2
    if mode == "round":
        return ((2 * x - 1) ** 2 * c * n * n <= 4 * v) & (4 * v < (2 * x + 1) ** 2 * c * n * n)
    return (x * x * c * n * n <= v) & (v < (x + 1) ** 2 * c * n * n)


def mean_sums(n, m, mode):
    """Every S = k_1 + ... + k_5 whose mean 2000 S / n (hundredths of a percent) matches m."""
    if mode == "round":
        return [S for S in range(5 * n + 1) if (2 * m - 1) * n <= 4000 * S < (2 * m + 1) * n]
    return [S for S in range(5 * n + 1) if m * n <= 2000 * S < (m + 1) * n]


def analyse(n, mean_pct, sd_pct, mode):
    """(mean possible, SD possible for some mean, mean and SD possible together), sample or population SD."""
    x, m = round(sd_pct * 100), round(mean_pct * 100)
    assert (x + 1) ** 2 * 25 * n * n < 10 ** 8 * M_LIMIT  # every M that can match x is enumerated
    sums = mean_sums(n, m, mode)
    sd_any = joint = False
    for ddof in (1, 0):
        ok = sd_match(T0_M, n, x, ddof, mode) & (T0_max <= n)
        if not ok.any():
            continue
        sd_any = True
        for S in sums:
            r = S - T0_sum[ok]
            joint = joint or bool(np.any((r >= 0) & (r % 5 == 0) & (r // 5 + T0_max[ok] <= n)))
    return bool(sums), sd_any, joint


yn = {True: "yes", False: "no"}
res = {}
for mode in ("round", "trunc"):
    print(f"[{'rounding' if mode == 'round' else 'truncation (mean and SD)'}]  for each n: mean possible / "
          f"SD possible for some mean / mean and SD possible together")
    print(f"  {'row':<26} {'reported':>14}   " + "   ".join(f"{'n=' + str(n):<12}" for n in NS))
    for name, m, s in reported:
        cells = []
        for n in NS:
            res[mode, n, name] = analyse(n, m, s, mode)
            cells.append("/".join(yn[v] for v in res[mode, n, name]))
        print(f"  {name:<26} {m:6.2f} +/- {s:4.2f}   " + "   ".join(f"{c:<12}" for c in cells))
rows24 = [r[0] for r in reported[:7]]
for mode in ("round", "trunc"):
    sd114 = [r for r in rows24 if res[mode, 114, r][1]]
    joint_any = [(r, n) for r in [x[0] for x in reported] for n in NS if res[mode, n, r][2]]
    print(f"Summary ({'rounding' if mode == 'round' else 'truncation'}): Tables 2-4 SDs possible on 114 samples for "
          f"some mean: {sd114 if sd114 else 'none'}; reported mean +/- SD pairs (Tables 2-4 and 6) possible on "
          f"any of n = 114, 56, 57, 58: {joint_any if joint_any else 'none'}")
t6_114 = [r[0] for r in reported[7:] if not res["round", 114, r[0]][0]]
print(f"Table 6 means not possible as five-run means on 114 samples (rounding): {t6_114}")
ties = 0
for name, m_, s_ in reported:
    x_, mm = round(s_ * 100), round(m_ * 100)
    for n in NS:
        ties += sum(1 for S in range(5 * n + 1) if 4000 * S in ((2 * mm - 1) * n, (2 * mm + 1) * n))
        for c in (20, 25):
            ties += int(np.sum((4 * 10 ** 8 * T0_M == (2 * x_ - 1) ** 2 * c * n * n)
                               | (4 * 10 ** 8 * T0_M == (2 * x_ + 1) ** 2 * c * n * n)))
print(f"Means or SDs lying exactly halfway between two two-decimal values (any row, n, SD type): {ties}; so the "
      f"rounding results hold for every tie-breaking convention.")

from fractions import Fraction  # noqa: E402


def hundredths(fr):
    """A non-negative Fraction (in percent) rounded to hundredths, exactly; ties do not occur here."""
    h = fr * 100
    fl = h.numerator // h.denominator
    assert h - fl != Fraction(1, 2)
    return fl + (1 if h - fl > Fraction(1, 2) else 0)


single = {hundredths(Fraction(100 * k, 114)) for k in range(115)}
n_coinc = sum(1 for S in range(571) if hundredths(Fraction(100 * S, 570)) in single)
print(f"\nFive-run means on 114 samples are multiples of 1/570; {n_coinc} of the 571 possible values equal a "
      f"single-run value k/114 to two decimals (about one in five).")
print("Mean accuracies reported in Tables 2-4, compared with single-run values k/114 (two decimals, exact):")
for m in (98.25, 92.11, 69.30, 92.98, 94.74, 95.61, 96.49):
    ks = [k for k in range(115) if hundredths(Fraction(100 * k, 114)) == round(m * 100)]
    print(f"  {m:6.2f}%  " + (f"= {ks[0]}/114 = {100 * ks[0] / 114:.4f}% to two decimals" if ks else "no single-run value"))
t6_114_t = [r[0] for r in reported[7:] if not res["trunc", 114, r[0]][0]]
print(f"Table 6 means not possible as five-run means on 114 samples (truncation): {t6_114_t}")

print("\nAccuracies printed to four decimals (the released code prints them with :.4f). With p_i = round(10^4 k_i / n),")
print("the accuracy of run i in hundredths of a percent (no ties occur for these n), a five-run mean is sum p_i / 5 and")
print("the SDs are sqrt(M_p/20) and sqrt(M_p/25), M_p = sum_{i<j} (p_i - p_j)^2. A reported mean +/- SD counts below as")
print("possible if one 5-tuple of counts matches the mean (from exact or four-decimal accuracies) and the SD (from exact")
print("or four-decimal accuracies, sample or population), both rounded or both truncated to two decimals; the case of a")
print("rounded mean with a truncated SD, or the reverse, is reported separately. Every tuple with max - min <= 40 is")
print("enumerated, which covers every tuple whose SD can match.")


def p4(k, n):
    """round(10^4 k / n) exactly, for integer arrays k; asserts that no tie occurs"""
    num = 10 ** 4 * k
    assert not np.any(((2 * num) % n == 0) & (((2 * num) // n) % 2 == 1))
    return (2 * num + n) // (2 * n)


PAIRS5 = [(i, j) for i in range(5) for j in range(i + 1, 5)]
any_reading, mixed = {}, {}
sd4_114 = {"round": set(), "trunc": set()}
for n in NS:
    for name, m, s in reported[:7]:
        assert (5 * (round(s * 100) + 1) + 1) * n < 40 * 10 ** 4  # max - min of the counts < 40 if a four-decimal SD matches
        any_reading[n, name] = mixed[n, name] = False
    for shift in range(n + 1):
        ok = T0_max + shift <= n
        if not ok.any():
            break
        S_ex, M_ex = T0_sum[ok] + 5 * shift, T0_M[ok]
        P4 = p4(T0[ok] + shift, n)
        S4 = P4.sum(1)
        M4 = sum((P4[:, i] - P4[:, j]) ** 2 for i, j in PAIRS5)
        for name, m, s in reported[:7]:
            X, x = round(m * 100), round(s * 100)
            mean_ok = {"round": (((2 * X - 1) * n <= 4000 * S_ex) & (4000 * S_ex < (2 * X + 1) * n))
                       | ((5 * (2 * X - 1) <= 2 * S4) & (2 * S4 < 5 * (2 * X + 1))),
                       "trunc": ((X * n <= 2000 * S_ex) & (2000 * S_ex < (X + 1) * n)) | ((5 * X <= S4) & (S4 < 5 * X + 5))}
            sd_ok = {mode: np.zeros(S4.shape, dtype=bool) for mode in ("round", "trunc")}
            for ddof, c in ((1, 20), (0, 25)):
                for mode in ("round", "trunc"):
                    if mode == "round":
                        s4 = ((2 * x - 1) ** 2 * c <= 4 * M4) & (4 * M4 < (2 * x + 1) ** 2 * c)
                    else:
                        s4 = (x * x * c <= M4) & (M4 < (x + 1) ** 2 * c)
                    sd_ok[mode] |= sd_match(M_ex, n, x, ddof, mode) | s4
                    if n == 114 and s4.any():
                        sd4_114[mode].add(f"{s:.2f} ({'sample' if ddof == 1 else 'population'})")
            any_reading[n, name] |= bool(np.any(mean_ok["round"] & sd_ok["round"]) or np.any(mean_ok["trunc"] & sd_ok["trunc"]))
            mixed[n, name] |= bool(np.any(mean_ok["round"] & sd_ok["trunc"]) or np.any(mean_ok["trunc"] & sd_ok["round"]))
print("Tables 2-4: mean +/- SD possible with both values rounded or both truncated (any accuracies, any SD type):")
for name, m, s in reported[:7]:
    print(f"  {name:<26} {m:6.2f} +/- {s:4.2f}   " + "   ".join(f"n={n}: {yn[any_reading[n, name]]:<4}" for n in NS))
print(f"  Summary: possible pairs: {[(r, n) for (n, r), v in any_reading.items() if v] or 'none'}")
print(f"  With one value rounded and the other truncated: possible pairs: "
      f"{[(r, n) for (n, r), v in mixed.items() if v] or 'none'}  (e.g. counts 104, 104, 105, 106, 106 on 114: mean "
      f"{100 * 525 / 570:.4f}% rounds to 92.11, sample SD {100 / 114 * math.sqrt(20 / 20):.4f}% truncates to 0.87)")
print(f"Tables 2-4 SDs possible on 114 samples for some mean, from four-decimal accuracies: rounding: "
      f"{sorted(sd4_114['round']) or 'none'}; truncation: {sorted(sd4_114['trunc']) or 'none'}")
print("(so the statement that no SD alone is possible on 114 samples, whatever the mean, needs exact accuracies k/114)")
print("Table 6 means, four-decimal accuracies, any spread: each p_i differs from 10^4 k_i/n by less than 1/2, so the mean")
print("differs from 2000 S/n by less than 1/2 hundredth; a reported mean X is then matched only if |2000 S/114 - X| < 1")
print("(rounding) or X - 1/2 < 2000 S/114 < X + 3/2 (truncation) for some integer S = k_1 + ... + k_5:")
for name, m, s in reported[7:]:
    X = round(m * 100)
    c_r = [S for S in range(571) if abs(Fraction(2000 * S, 114) - X) < 1]
    c_t = [S for S in range(571) if X - Fraction(1, 2) < Fraction(2000 * S, 114) < X + Fraction(3, 2)]
    print(f"  {name:<26} {m:6.2f}: S possible (rounding) {c_r or 'none'}, (truncation) {c_t or 'none'}")

# --------------------------------------------------------------------------
hdr("9. Table 7 (single runs): granularity check")
for name, val, n in (("High-dim synthetic TFGD", 61.25, 400), ("High-dim synthetic SGD", 49.00, 400),
                     ("Noisy digits TFGD", 95.83, 360), ("Noisy digits SGD", 75.83, 360)):
    k = round(val / 100 * n)
    print(f"  {name:<26} {val:6.2f}%  n_test={n}:  {k}/{n} = {k / n * 100:.4f}%  -> {'consistent' if abs(k / n * 100 - val) < 0.006 else 'INCONSISTENT'}")

# --------------------------------------------------------------------------
hdr("10. Lemma 5.2, Remark 2, Section 5 and Fig. 1: elementary checks")
print("Lemma 5.2 proof: sum_{j=0}^K e^{-lambda j} = (1 - e^{-lambda(K+1)})/(1 - e^{-lambda}); the proof writes")
print("(1 - e^{-lambda K})/(1 - e^{-lambda}), which omits the term j = K, e^{-lambda K}:")
for lam, Kk in ((0.1, 10), (0.5, 4), (1.0, 2)):
    s = float(np.sum(np.exp(-lam * np.arange(Kk + 1))))
    proof = (1 - np.exp(-lam * Kk)) / (1 - np.exp(-lam))
    print(f"  lambda={lam}, K={Kk}: sum = {s:.12f}, proof's expression = {proof:.12f}, difference = {s - proof:.10f},"
          f" e^(-lambda K) = {np.exp(-lam * Kk):.10f}")
lams = np.linspace(0.01, 5, 500)
print(f"1 - e^-lambda < lambda for every lambda in [0.01, 5]: {bool(np.all(1 - np.exp(-lams) < lams))}"
      "  -> (1-e^{-lK})/(1-e^{-l}) <= (1-e^{-lK})/l in the proof of Lemma 5.2 is reversed")
print(f"1 - e^-lambda >= lambda/2 holds for lambda in [0.01, 1.59]: {bool(np.all(1 - np.exp(-lams[lams <= 1.59]) >= lams[lams <= 1.59] / 2))}"
      "  -> it gives only (1-e^{-lK})/(1-e^{-l}) <= 2(1-e^{-lK})/l")
print("Remark 2, j_max = ceil(5/lambda): since ceil(x) < x + 1, e^(-lambda j_max) > e^(-5-lambda), and e^(-5-lambda) > 1e-5")
print(f"iff lambda < 5 ln 10 - 5 = {5 * np.log(10) - 5:.4f}; so e^(-lambda j_max) > 1e-5 for every lambda < 6.5, not < 1e-5.")
lam_g = np.linspace(0.001, 6.5, 1300000)
v_g = np.exp(-lam_g * np.ceil(5 / lam_g))
print(f"  on {lam_g.size} values of lambda in [0.001, 6.5]: e^(-lambda j_max) >= e^(-5-lambda) (1 - 1e-9): "
      f"{bool(np.all(v_g >= np.exp(-5 - lam_g) * (1 - 1e-9)))};  min {v_g.min():.3e} (> 1e-5);  max {v_g.max():.4e} "
      f"(= e^-5, when 5/lambda is an integer; e.g. lambda = 0.5: {np.exp(-0.5 * math.ceil(5 / 0.5)):.4e})")
print("Truncation errors of Eq. (2) decay exponentially, not super-exponentially: see the lower bound in section 2.")
print("Remark 2 'stabilized form' S_k = g_k + e^-lambda (S_{k-1} - g_{k-1}): S_k - g_k = e^-lambda (S_{k-1} - g_{k-1}), so")
print("S_k = g_k + e^(-lambda k)(S_0 - g_0), whereas Eq. (21) gives S_k = sum_{j<k} e^(-lambda j) g_{k-j} + e^(-lambda k) S_0:")
rng_s = np.random.default_rng(3)
g_s = rng_s.standard_normal(60)
for lam in (0.005, 0.5):
    q = np.exp(-lam)
    S_st, S_21, err_id, gap = 0.0, 0.0, 0.0, 0.0
    for k in range(1, 60):
        S_st = g_s[k] + q * (S_st - g_s[k - 1])
        S_21 = g_s[k] + q * S_21
        err_id = max(err_id, abs(S_st - (g_s[k] + q ** k * (0.0 - g_s[0]))))
        gap = max(gap, abs(S_st - S_21))
    print(f"  lambda={lam}, S_0 = 0, 59 steps on N(0,1) gradients: max |S_k - (g_k - e^(-lambda k) g_0)| = {err_id:.1e};"
          f"  max |S_k(stabilized) - S_k(Eq. 21)| = {gap:.3f}")
print("Section 5: memory O(d/lambda) vs O(dk) of Zhou-FGD is a factor k lambda, not '8x', at k = 100, lambda = 0.5: "
      f"{100 * Fraction(1, 2)}")
print("Truncation after 5/lambda steps keeps the lags 0..floor(5/lambda), i.e. floor(5/lambda) + 1 gradients per parameter, "
      "not a fixed 5x: " + ", ".join(f"lambda={l}: {math.floor(5 / Fraction(l)) + 1}" for l in ("0.1", "0.5", "1")))
print("Fig. 1 plots the formula 30/lambda (30 = number of features): " +
      ", ".join(f"lambda={l}: {30 / l:g}" for l in (0.1, 0.5, 1.0)) + "  (Section 5: '~60 units for d = 30, lambda = 0.5')")
S_w = np.zeros(30)      # optimiser buffer for the 30 weights (released code: np.zeros_like(params))
S_b = np.zeros_like(0.0)  # optimiser buffer for the bias
print(f"Released optimiser state for logistic regression: two buffers, {S_w.size} + {S_b.size} = {S_w.size + S_b.size} "
      f"float64 values = {S_w.nbytes + S_b.nbytes} bytes of data, for every alpha and lambda")

# --------------------------------------------------------------------------
hdr("11. Corrected Theorems 4.1 and 4.2 (corrigendum Section C3): constants, identity of Lemma C1, bounds")
# Iteration theta_{k+1} = theta_k - eta * sum_{j=0}^k a_j g_{k-j} with a_j >= 0, d = sum a_j, D = sum j a_j.
# Eq. (2): a_j = |binom(alpha, j)| e^{-lambda j};  released recursion (heavy ball): a_j = e^{-lambda j}.
from scipy.optimize import minimize  # noqa: E402


def kernel_eq2(a, lam, J):
    return abs_gl(a, J) * np.exp(-lam * np.arange(J))


def d_D_eq2(a, lam):
    q = np.exp(-lam)
    return 2 - (1 - q) ** a, a * q * (1 - q) ** (a - 1)


print("Closed forms d = 2-(1-q)^a, D = a q (1-q)^(a-1), q = e^-lambda, against the series (20000 terms):")
for a, lam in ((0.3, 0.1), (0.6, 0.5), (0.9, 1.0), (0.6, 0.1), (0.99, 0.05)):
    w = kernel_eq2(a, lam, 20000)
    d_cf, D_cf = d_D_eq2(a, lam)
    print(f"  alpha={a:<4} lambda={lam:<4}: d = {d_cf:.6f} (series {w.sum():.6f}),"
          f"  D = {D_cf:.6f} (series {(np.arange(w.size) * w).sum():.6f}),  1/(d+2D) = {1 / (d_cf + 2 * D_cf):.4f}")
print(f"Nearly equal total weights compared in Section C5.4: d at (0.9, 0.5) = {d_D_eq2(0.9, 0.5)[0]:.6f}; released "
      f"recursion at lambda = 1: 1/(1-e^-1) = {1 / (1 - np.exp(-1)):.6f}; d at (0.7, 0.3) = {d_D_eq2(0.7, 0.3)[0]:.6f}")

rng = np.random.default_rng(2026)
n = 20
# P1: convex quadratic, L = 1
Qm, _ = np.linalg.qr(rng.standard_normal((n, n)))
A = Qm @ np.diag(np.geomspace(1e-2, 1.0, n)) @ Qm.T
bq = rng.standard_normal(n)
th_star_q = np.linalg.solve(A, bq)
P1 = dict(name="convex quadratic", L=1.0,
          f=lambda t: 0.5 * np.einsum("...i,ij,...j->...", t, A, t) - t @ bq,
          g=lambda t: t @ A - bq, convex=True, theta_star=th_star_q)
P1["f_inf"] = float(P1["f"](th_star_q))
# P2: logistic regression (convex), L = ||X||^2 / (4 m)
Xl = rng.standard_normal((200, n))
sl = np.where(Xl @ rng.standard_normal(n) + 2.0 * rng.standard_normal(200) > 0, 1.0, -1.0)


def f_log(t):
    return np.mean(np.logaddexp(0.0, -sl * (t @ Xl.T)), axis=-1)


def g_log(t):
    return -((sl / (1.0 + np.exp(sl * (t @ Xl.T)))) @ Xl) / Xl.shape[0]


opt = minimize(f_log, np.zeros(n), jac=g_log, method="BFGS", options={"gtol": 1e-13, "maxiter": 10000})
P2 = dict(name="logistic regression", L=np.linalg.norm(Xl, 2) ** 2 / (4 * Xl.shape[0]), f=f_log, g=g_log,
          convex=True, theta_star=opt.x, f_inf=float(opt.fun))
# P3: non-convex robust regression, f = mean log(1 + (B t - c)^2), L <= 2 ||B||^2 / m, inf f = 0 (B has full row rank)
Bn = rng.standard_normal((10, n))
cn = 3.0 * rng.standard_normal(10)


def f_nc(t):
    r = t @ Bn.T - cn
    return np.mean(np.log1p(r ** 2), axis=-1)


def g_nc(t):
    r = t @ Bn.T - cn
    return (2 * r / (1 + r ** 2)) @ Bn / Bn.shape[0]


P3 = dict(name="non-convex log(1+r^2)", L=2 * np.linalg.norm(Bn, 2) ** 2 / Bn.shape[0], f=f_nc, g=g_nc,
          convex=False, f_inf=0.0)
theta0 = 3.0 * rng.standard_normal(n)


def run_memory(prob, a_w, eta, K, sigma=0.0, reps=1, seed=0):
    """Exact iteration with full history. Returns iterates (K+1, reps, n), true gradients and noisy gradients (K, reps, n)."""
    r = np.random.default_rng(seed)
    th = np.tile(theta0, (reps, 1))
    TH, G, Gt = [th], np.zeros((K, reps, n)), np.zeros((K, reps, n))
    for k in range(K):
        G[k] = prob["g"](th)
        Gt[k] = G[k] + (sigma / np.sqrt(n)) * r.standard_normal((reps, n)) if sigma > 0 else G[k]
        th = th - eta * np.tensordot(a_w[:k + 1], Gt[k::-1], axes=(0, 0))
        TH.append(th)
    return np.array(TH), G, Gt


K = 300
kernels = [("Eq. (2)", a, lam) for a, lam in ((0.3, 0.1), (0.6, 0.5), (0.9, 1.0), (0.6, 0.1), (0.99, 0.05))]
kernels += [("heavy ball", None, lam) for lam in (0.1, 0.5, 1.0)]
worst_id, worst_i, worst_ii, worst_lim = 0.0, 0.0, 0.0, 0.0
for prob in (P1, P2, P3):
    for kind, a, lam in kernels:
        if kind == "Eq. (2)":
            a_w = kernel_eq2(a, lam, K)
            d, D = d_D_eq2(a, lam)
        else:
            q = np.exp(-lam)
            a_w = q ** np.arange(K)
            d, D = 1 / (1 - q), q / (1 - q) ** 2
        T = d - np.concatenate(([0.0], np.cumsum(a_w)))  # T_m = sum_{j >= m} a_j, m = 0..K
        for eta in (1 / (prob["L"] * (d + 2 * D)), 1 / (3 * prob["L"] * (d + 2 * D))):
            TH, G, _ = run_memory(prob, a_w, eta, K)
            th, g = TH[:, 0], G[:, 0]
            # identity of Lemma C1: theta_k - z_k = eta sum_{i<k} T_{k-i} g_i with z_k = theta_0 - eta d sum_{i<k} g_i
            for k in range(1, K + 1):
                z = theta0 - eta * d * g[:k].sum(0)
                lag = eta * (T[k - np.arange(k)][:, None] * g[:k]).sum(0)
                worst_id = max(worst_id, np.linalg.norm(th[k] - z - lag) / (1 + np.linalg.norm(th[k])))
            Ks = np.arange(1, K + 1)
            gn2 = np.cumsum((g ** 2).sum(1))
            delta = prob["f"](theta0) - prob["f_inf"]
            worst_i = max(worst_i, np.max((gn2 / Ks) / (2 * delta / (eta * d * Ks))))
            if prob["convex"]:
                gap = np.cumsum(np.array([prob["f"](t) for t in th[:K]]) - prob["f_inf"])
                R2 = np.sum((theta0 - prob["theta_star"]) ** 2)
                worst_ii = max(worst_ii, np.max((gap / Ks) / (R2 / (eta * d * Ks))))
            worst_lim = max(worst_lim, gn2[-1] * eta * d / (2 * delta))
print(f"Identity of Lemma C1, max relative residual over all runs: {worst_id:.2e}")
print(f"Theorem 4.1 (corrected), part (i): max over runs and K<=300 of LHS / (2 Delta/(eta d K)) = {worst_i:.4f}  (<= 1 required)")
print(f"Theorem 4.1 (corrected), part (ii): max over convex runs and K<=300 of LHS / (R^2/(eta d K)) = {worst_ii:.4f}  (<= 1 required)")
print("  (3 problems x 8 kernels x 2 steps eta = 1/(L(d+2D)) and 1/(3L(d+2D)); kernels: Eq. (2) at 5 (alpha, lambda), heavy ball at 3 lambda)")

# Stochastic: E[xi_k | F_k] = 0, E||xi_k||^2 = sigma^2 (Gaussian), 400 replications
worst_s, worst_sc, n_s, n_sc = 0.0, 0.0, 0, 0
for prob in (P1, P2, P3):
    for kind, a, lam in (("Eq. (2)", 0.6, 0.5), ("Eq. (2)", 0.9, 1.0), ("Eq. (2)", 0.3, 0.1), ("heavy ball", None, 0.5)):
        if kind == "Eq. (2)":
            a_w = kernel_eq2(a, lam, 200)
            d, D = d_D_eq2(a, lam)
        else:
            q = np.exp(-lam)
            a_w = q ** np.arange(200)
            d, D = 1 / (1 - q), q / (1 - q) ** 2
        for sigma in (0.5, 2.0):
            for eta in (1 / (prob["L"] * (d + 2 * D)), 1 / (5 * prob["L"] * (d + 2 * D))):
                TH, G, _ = run_memory(prob, a_w, eta, 200, sigma=sigma, reps=400, seed=7)
                # (i): (1/K) sum_k ||grad f(theta_k)||^2, per replication
                per_rep = (G ** 2).sum(2).mean(0)
                delta = prob["f"](theta0) - prob["f_inf"]
                bound = 2 * delta / (eta * d * 200) + prob["L"] * eta * (d + D) * sigma ** 2
                worst_s = max(worst_s, (per_rep.mean() + 3 * per_rep.std(ddof=1) / np.sqrt(per_rep.size)) / bound)
                n_s += 1
                if prob["convex"]:  # (ii): (1/K) sum_k (f(theta_k) - f*), per replication
                    gap = (prob["f"](TH[:200]) - prob["f_inf"]).mean(0)
                    bound_c = np.sum((theta0 - prob["theta_star"]) ** 2) / (eta * d * 200) + eta * (d + D) * sigma ** 2
                    worst_sc = max(worst_sc, (gap.mean() + 3 * gap.std(ddof=1) / np.sqrt(gap.size)) / bound_c)
                    n_sc += 1
print(f"Theorem 4.2 (corrected), part (i): max over {n_s} settings of (mean + 3 SE) / bound, K = 200, "
      f"400 replications = {worst_s:.4f}  (<= 1 expected)")
print(f"Theorem 4.2 (corrected), part (ii): max over {n_sc} convex settings of (mean + 3 SE) / bound, K = 200, "
      f"400 replications = {worst_sc:.4f}  (<= 1 expected)")
print("  (problems P1-P3 as above, Gaussian noise with E||xi||^2 = sigma^2 in {0.25, 4}, eta = 1/(L(d+2D)) and 1/(5L(d+2D)))")

print("\nE[xi_k | F_k] = 0 cannot be weakened to E[xi_k] = 0 (corrigendum, example of Section C2 used in the Scope paragraph")
print("of Section C3, with a constant step): Eq. (2) on L(theta) = theta^2/2")
print("(L = 1, inf L = 0), theta_0 = 0 (Delta = 0), xi_k = xi_0 for every k, xi_0 = +sigma or -sigma with probability 1/2.")
print("Then E[xi_k] = 0 and E xi_k^2 = sigma^2, but E[xi_k | F_k] = xi_0 for k >= 1. The iterates converge to -xi_0, so the")
print("left side of (i) tends to sigma^2, while its right side is L eta (d+D) sigma^2 < sigma^2. Exact expectation (both signs),")
print("sigma = 1, (alpha, lambda) = (0.6, 0.5), eta = 1/(L(d+2D)):")
a_c, lam_c = 0.6, 0.5
d_c, D_c = d_D_eq2(a_c, lam_c)
eta_c = 1 / (d_c + 2 * D_c)
w_c = kernel_eq2(a_c, lam_c, 4000)
rhs_c = eta_c * (d_c + D_c)
print(f"  d = {d_c:.6f}, D = {D_c:.6f}, eta = {eta_c:.6f}, right side of (i) = L eta (d+D) sigma^2 = {rhs_c:.6f}")
for K_c in (5, 10, 100, 4000):
    lhs_c = 0.0
    for xi0 in (1.0, -1.0):
        th, G_c, sq = 0.0, np.zeros(K_c), 0.0
        for k in range(K_c):
            sq += th ** 2  # ||grad L(theta_k)||^2
            G_c[k] = th + xi0  # noisy gradient
            th = th - eta_c * np.dot(w_c[:k + 1], G_c[k::-1])
        lhs_c += 0.5 * sq / K_c
    print(f"  K={K_c:>4}: left side of (i) = (1/K) sum_(k<K) E grad L(theta_k)^2 = {lhs_c:.6f}  "
          f"({'exceeds' if lhs_c > rhs_c else 'below'} the right side)")

print("\nTuned step of Theorem 4.2 (corrected): eta = min{1/(L(d+2D)), R/(sigma sqrt(d(d+D)K))} gives, for (ii),")
print("R^2/(eta d K) + eta (d+D) sigma^2 <= L(d+2D) R^2/(dK) + 2 sigma R sqrt((d+D)/(dK)); for (i), with R^2 replaced by")
print("2 Delta/L in the step and in the bound, 2 Delta/(eta d K) + L eta (d+D) sigma^2 <= L * (the same bound).")
rng_t = np.random.default_rng(11)
N_t = 200000
L_, d_, D_, sg_, R_, Dl_ = 10 ** rng_t.uniform([-2, -1, -3, -3, -3, -3], [2, 1, 2, 2, 2, 2], size=(N_t, 6)).T
K_ = rng_t.integers(1, 10 ** 6, size=N_t).astype(float)
worst_t = []
for Rr, mult in ((R_, 1.0), (np.sqrt(2 * Dl_ / L_), L_)):
    eta_ = np.minimum(1 / (L_ * (d_ + 2 * D_)), Rr / (sg_ * np.sqrt(d_ * (d_ + D_) * K_)))
    val = mult * (Rr ** 2 / (eta_ * d_ * K_) + eta_ * (d_ + D_) * sg_ ** 2)
    bnd = mult * (L_ * (d_ + 2 * D_) * Rr ** 2 / (d_ * K_) + 2 * sg_ * Rr * np.sqrt((d_ + D_) / (d_ * K_)))
    worst_t.append(float(np.max(val / bnd)))
print(f"  {N_t} random (L, d, D, sigma, R, Delta, K): max of right side / stated bound = {worst_t[0]:.12f} (ii), "
      f"{worst_t[1]:.12f} (i)  (<= 1 up to rounding)")

# --------------------------------------------------------------------------
hdr("12. Further errors in the published proofs (corrigendum Sections C1-C2, letter Section 1)")
from scipy.special import gammaincc  # noqa: E402

print("Lemma 4.1 proof, inequality attributed to Watson's lemma:")
print("  int_k^inf x^-(1+a) e^(-l x) dx <= e^(-l k)/(l k^(1+a)) Gamma(1+a, l k)   (upper incomplete gamma function).")
print("Left side by quadrature and in closed form l^a Gamma(-a, x) = l^a (x^-a e^-x - Gamma(1-a, x))/a, x = l k;")
print("E := e^(-l k)/(l k^(1+a)), so that the right side is E Gamma(1+a, l k). At (alpha, lambda) = (0.6, 0.5):")
a, lam = 0.6, 0.5
fails = []
for k in range(1, 41):
    x = lam * k
    lhs_q = quad(lambda t: t ** (-1 - a) * np.exp(-lam * t), k, np.inf, epsabs=0, epsrel=1e-12, limit=200)[0]
    lhs_cf = lam ** a * (x ** (-a) * np.exp(-x) - gammaincc(1 - a, x) * gamma(1 - a)) / a
    E = np.exp(-x) / (lam * k ** (1 + a))
    G_up = gammaincc(1 + a, x) * gamma(1 + a)
    if lhs_q > E * G_up:
        fails.append(k)
    if k in (1, 2, 3, 5, 10, 20, 40):
        print(f"  k={k:>2}: left = {lhs_q:.6e} (closed form {lhs_cf:.6e}), left/E = {lhs_q / E:.4f}, "
              f"Gamma(1+a, l k) = {G_up:.4f}, right = {E * G_up:.6e}  -> {'FAILS' if lhs_q > E * G_up else 'holds'}")
print(f"  fails for k in {fails[0]}..{fails[-1]} ({len(fails)} values, contiguous: {fails == list(range(fails[0], fails[-1] + 1))}) "
      f"of k = 1..40; left/E -> 1 while Gamma(1+a, l k) -> 0")

print("\nLemma 4.2 proof: Eq. (15) with e^(-2 lambda t) <= 1 and Eq. (16), B(a,a) = Gamma(a)^2/Gamma(2a), give")
print("Gamma(1+2a)/Gamma(1+a)^2 * Gamma(a)^2/Gamma(2a) = 2/a, not the bound of Eq. (13):")
for a in (0.3, 0.6, 0.9):
    val = gamma(1 + 2 * a) / gamma(1 + a) ** 2 * gamma(a) ** 2 / gamma(2 * a)
    print(f"  alpha={a}: {val:.12f}   2/alpha = {2 / a:.12f}   Eq. (13) at lambda = 1: "
          f"{gamma(1 + 2 * a) / (2 ** (2 * a) * gamma(1 + a) ** 2):.6f}")

print("\nTheorem 4.1 proof, bound preceding Eq. (11) with eta = 1/L: from Eq. (10) and ||theta_{k-j} - theta*|| <=")
print("(1 + d)^j ||theta_k - theta*|| it needs sum_j |w_j| e^(-lambda j) (1 + d)^j < inf. With r := e^(-lambda)(1 + d) and")
print("|w_j| >= a(1-a)/j^2 (section 2), the terms are >= a(1-a) r^j / j^2 -> inf when r > 1, and d > 1 gives r > 2 e^-lambda > 1")
print(f"for every lambda < ln 2 = {np.log(2):.6f}:")
for a in (0.3, 0.6, 0.9):
    for lam in (0.1, 0.5, 0.69):
        r_p = np.exp(-lam) * (1 + d_paper(a, lam))
        r_c = np.exp(-lam) * (1 + 2 - (1 - np.exp(-lam)) ** a)
        ps = [float(np.sum(abs_gl(a, J + 1) * r_p ** np.arange(J + 1))) for J in (10, 50, 200)]
        print(f"  alpha={a}, lambda={lam}: r = {r_p:.4f} (published d), {r_c:.4f} (corrected d); partial sums to "
              f"J = 10, 50, 200 (published d): " + ", ".join(f"{p:.3e}" for p in ps))
lg = np.linspace(1e-4, np.log(2) - 1e-9, 2000)
ag = np.linspace(0.001, 0.999, 999)
AG, LG = np.meshgrid(ag, lg)
print(f"  min of r over alpha in [0.001, 0.999], lambda in (0, ln 2): published d {np.min(np.exp(-LG) * (1 + d_paper(AG, LG))):.6f}, "
      f"corrected d {np.min(np.exp(-LG) * (3 - (1 - np.exp(-LG)) ** AG)):.6f}  (> 1)")

print("\nTheorem 4.1 proof, error (ii): with eta = 1/L the dropped term eta^2 (L d/(1-alpha))^2 V_k = (d/(1-alpha))^2 V_k >= V_k,")
A1, L1 = np.meshgrid(np.linspace(0.001, 0.999, 999), np.logspace(-4, 2, 1000))
print(f"since d > 1 > 1 - alpha; min of (d/(1-alpha))^2 over alpha in [0.001, 0.999], lambda in [1e-4, 100]: "
      f"{np.min((d_paper(A1, L1) / (1 - A1)) ** 2):.6f}")
print("Error (v): the terms 2 eta C e^(-lambda k) of Eq. (11) contribute (1/K) sum_(k<K) 2 eta C e^(-lambda k) >= 2 eta C/K")
print("(the k = 0 term), i.e. order 1/K, whereas Eq. (12) has a term of order e^(-lambda K). At lambda = 0.5:")
for Kk in (10, 100, 1000):
    print(f"  K={Kk:>4}: (1/K) sum_(k<K) e^(-lambda k) = {np.sum(np.exp(-0.5 * np.arange(Kk))) / Kk:.4e},  1/K = {1 / Kk:.4e},"
          f"  e^(-lambda K) = {np.exp(-0.5 * Kk):.4e}")

print("\nDone.")
